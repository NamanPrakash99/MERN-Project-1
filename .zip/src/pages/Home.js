// src/Home.js
function Home() {
  return <div>Welcome to Home</div>;
}

export default Home; 
