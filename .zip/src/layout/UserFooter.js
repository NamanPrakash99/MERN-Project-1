function Footer() {
    return (
        <>
            <div className="container-fluid bg-light 
text-center py-3">
                <p>I am Footer!</p>
            </div>
        </>
    );
}

export default Footer;
