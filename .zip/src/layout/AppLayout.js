import App from "../App";
import Footer from "./Footer";
import Header from "./Header";

function AppLayout({ children }) {
    return (
        <>
            <Header />
            { children }
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            <br></br>
            
            <Footer />
        </>
    );
}

export default AppLayout;
