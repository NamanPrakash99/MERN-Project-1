function Footer() {
    return (
        <>
            <div className="container-fluid text-center">
                <p>I am Footer!</p>
            </div>
        </>
    );
}

export default Footer;
